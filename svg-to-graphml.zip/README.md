# SVG to GraphML Converter

## 本地启动

```bash
npm install
npm run dev
```

浏览器访问 http://localhost:5173

## 部署到 GitHub Pages

```bash
npm run deploy
```

访问地址: https://roger1803.github.io/test
